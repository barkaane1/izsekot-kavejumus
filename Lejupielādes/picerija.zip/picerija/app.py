from flask import Flask, render_template, request
import random

app = Flask(__name__)

@app.route('/')
def sakums():
	joki = [
	"Apaļa pica kvadrātainā kastē, ko griež trijstūros –vienīgā matemātika, kurai es tiešām ticu.",
	"Pica nekad neuzdod liekus jautājumus. Pica tevi vienkārši saprot.",   
	"Trīs minūtes starp picas pasūtīšanu un kurjera zvanu pie durvīm ir dienas garākā stunda. Einšteinam bija taisnība par relativitāti.",
	"Mēģināt izpatikt visiem ir neiespējami. Tu neesi pica. Pat pica reizēm neiztur spiedienu, ja uz tās uzliek ananasu.",
	"Picas dalīšana ir augstākā mīlestības izpausme. Vai arī nopietns iemesls pilsoņu karam. Atkarīgs no tā, kurš paņēma pēdējo desu.",

	]
	dienas_citats = random.choice(joki)
	return render_template('index.html', citats=dienas_citats)    


@app.route('/jauns')
def jauns():    
	return render_template("jauns_pasutijums.html")


@app.route('/pasutit', methods=['POST'])
def pasutit():
	picas = {"S": 7, "M": 10, "L": 14}

	klients = request.form.get('klients')
	izmers = request.form.get('izmers')
	skaits = int(request.form.get('skaits'))

	cena = picas[izmers]

	if skaits > 3:
		kopsumma = skaits * cena * 0.85
	else:
		kopsumma = skaits * cena

	return render_template("pasutijuma_kopsavilkums.html", v = klients, i = izmers, s = skaits, k = kopsumma)

if __name__ == '__main__':
    # debug=True ļauj redzēt kļūdas un automātiski restartē serveri pēc saglabāšanas
    app.run(debug=True)